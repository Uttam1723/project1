module.exports = {
   options: {
      shorthandCompacting: false
   },
   plugin: {
      files: {
         'dist/jquery.tagsinput.min.css': ['src/jquery.tagsinput.css']
      }
   }
};
