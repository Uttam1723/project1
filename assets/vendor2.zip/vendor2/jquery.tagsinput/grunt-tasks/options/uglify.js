module.exports = {
   options: {
      mangle: true
   },
   plugin: {
      files: {
         'dist/jquery.tagsinput.min.js': ['src/jquery.tagsinput.js']
      }
   }
};
